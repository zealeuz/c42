#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	char	*str;

	str = (char *)s;
	while (*str != c)
	{
		if (*str == '\0')
		{
			if (c == 0)
				return (str);
			else
				return (NULL);
		}
		str++;
	}
	return (str);
}	
