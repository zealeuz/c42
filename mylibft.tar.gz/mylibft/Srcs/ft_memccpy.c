#include <string.h>

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	int	*ptr;
	size_t 	i;

	i = 0;
	ptr = dest;
	while (i < n)
	{
		*(ptr + i) = *((unsigned int *)src + i);
		if (*((unsigned int *)src + i) == (unsigned int)c)
			return (dest + i + 1);
	}
	return (NULL);
}
