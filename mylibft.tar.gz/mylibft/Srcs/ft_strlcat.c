#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	dlen;
	int	i;

	dlen = ft_strlen(dst);
	while (src[i] && ((dlen + i) <= size))
	{
		dst[dlen + i] = src[i];
		i++;
	}
	if (src[i])
		return (size);
	dst[dlen + i] = '\0';
	return (dlen + i);
}
