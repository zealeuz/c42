#include "libft.h"

void	ft_strclr(char *as)
{
	ft_memset(as, '\0', ft_strlen(as));
}
