#include "libft.h"

int	ft_countword(char const *s, char c)
{
	int	inword;
	int	i;
	int	count;

	inword = 0;
	i = 0;
	count = 0;
	while (s[i])
	{
		if ((s[i] != c) && (inword == 0))
		{
			inword = 1;
			count++;
		}
		if ((inword == 1) && (s[i] == c))
			inword = 0;
		i++;
	}
	return (count);
}

size_t	ft_len(const char *s, char c)
{
	size_t i;

	i = 0;
	while ((s[i] != c) && (s[i] != '\0'))
		i++;
	return (i);
}

char	**ft_strsplit(char const *s, char c)
{
	char	**tab;
	int	word;
	int	entry;

	entry = 0;
	word = ft_countword(s, c);
	if((tab = (char **)malloc(sizeof(*tab) * (word + 1))) == NULL)
		return (NULL);
	while (word != 0)
	{
		while ((*s == c) && (*s != '\0'))
			s++;
		tab[entry] = ft_strsub(s, 0, ft_len(s, c));
		s = s + ft_len(s, c);
		word--;
		entry++;
	}
	tab[entry] = '\0';
	return (tab);
}
