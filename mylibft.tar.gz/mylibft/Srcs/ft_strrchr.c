#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	char	*str;
	int	i;

	str = (char *)s;
	i = ft_strlen(s);
	str = str + i;
	while (*str != c && str >= s)
	{
		str--;
	}
	if (*str == c)
		return (str);
	else
		return (NULL);
}
