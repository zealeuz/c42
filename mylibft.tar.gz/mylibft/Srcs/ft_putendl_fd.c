#include "libft.h"

void	ft_putendl_fd(const char *s, int fd)
{
	ft_putstr(s, fd);
	ft_putchar('/n', fd);
}
