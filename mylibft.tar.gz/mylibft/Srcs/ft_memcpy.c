#include <strings.h>

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	size_t	i;
	char	*d2;
	char	*s2;

	d2 = (char*)dest;
	s2 = (char*)src;
	i = 0;
	while (i < n)
	{
		d2[i] = s2[i];
		i++;
	}
	return (dest);
}
