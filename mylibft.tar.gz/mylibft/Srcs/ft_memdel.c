#include "libft.h"

void	ft_memdel(void **ap)
{
	if (*ap)
		free (*ap);
	*ap = NULL;
}
