#include "libft.h"

int	ft_numlen(int n)
{
	int	len;

	len = 0;
	if (n < 0)
	{
		len++;
		n = n * -1;
	}
	while (n > 0)
	{
		len++;
		n = n / 10;
	}
	return (len);
}

char	*ft_itoa(int n)
{
	int	len;
	char	*str;
	int	neg;

	neg = 0;
	if (n < 0)
		neg = 1;
	len = ft_numlen(n);
	if ((str = (char*)malloc(sizeof(*str) * (len + 1))) == NULL)
		return (NULL);
	str[len] = '\0';
	if (neg == 1)
	{
		str[0] = '-';
		n = n * -1;
	}
	while ((len >= 0) && (n != 0))
	{
		str[len - 1] = (n % 10) + '0';
		n = n / 10;
		len--;
	}
	return (str);
}
