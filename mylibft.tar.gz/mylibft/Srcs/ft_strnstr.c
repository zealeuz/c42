#include "libft.h"

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	char	*temp;
	size_t 	i;
	int	j;

	i = 0;
	temp = (char *)haystack;
	if (*temp == '\0')
		return (temp);
	while (*temp)
	{
		while (temp[j] == needle[i] && needle[i] && temp[j] \
						&& (i < len))
		{
			i++;
			j++;
		}
		if (needle[i] == '\0')
			return (temp);
		j = 0;
		i = 0;
		temp++;
	}
	return (NULL);
}
