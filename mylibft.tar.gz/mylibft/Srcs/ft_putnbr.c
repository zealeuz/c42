#include "libft.h"

void	ft_putnbr(int n)
{
	int	i;
	char	*str;

	str = ft_itoa(n);
	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
	free(str);
}
