#include "libft.h"

char	*ft_strtrim(char const *s)
{
	char	*str;
	int	beg;
	int	end;
	int	i;

	i = 0;
	beg = 0;
	end = ft_strlen((char*)s);
	while ((s[beg] == ' ' || s[beg] == '\n' || s[beg] == '\t') && (s[beg]))
		beg++;
	end = ft_strlen((char*)s) - 1;
	while ((s[end] == ' ' || s[end] == '\n' || s[end] == '\t') && ( end >= 0))
		end--;
	if ((str = (char*)malloc(sizeof(char) * (end - beg + 2))) == NULL)
		return (NULL);
	while (beg <= end)
	{
		str[i] = s[beg];
		beg++;
		i++;
	}
	str[i] = '\0';
	return (str);
}
